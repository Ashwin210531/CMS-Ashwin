﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using DataAccess;
using Entity;

namespace Business
{
    public class billingBusiness
    {

        billingDb db = new billingDb();


        public List<E_BILL> ViewAllBill()
        {
            return db.ViewAllBill();
        }


        public List<E_BILL> ViewBillById(int id)
        {
            return db.ViewBillById(id);
        }


        public void UpdateBill(E_BILL bill)
        {
            db.UpdateBill(bill);
        }


        public void DeleteBill(int id)
        {
            db.DeleteBill(id);
        }


        public void SaveBill(E_BILL bill)
        {
            if (bill.id > 0)
            {
                db.UpdateBill(bill);
            }
            else
            {
                db.InsertBill(bill);
            }
        }
        public List<E_BILL> SearchBill(string billno, string invoicedate)
        {
            return db.SearchBill(billno,invoicedate);
        }
    }
}
