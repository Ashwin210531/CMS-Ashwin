﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CMS.Models;
using Entity;
using Business;

namespace CMS.Controllers
{
    public class billingController : Controller
    {
        //
        // GET: /billing/

        public ActionResult Index()
        {
            billing bil = new billing();
            List<E_BILL> lstentBill = new billingBusiness().ViewAllBill();
            bil.lstBilling = ConvertToModelBilling(lstentBill);
            return View(bil);
        }

        private List<billing> ConvertToModelBilling(List<E_BILL> lstentBill)
        {
            List<billing> lstBill = new List<billing>();
            foreach (var item in lstentBill)
            {
                lstBill.Add(new billing
                {
                    id = item.id,
                    billno=item.billno,
                    invoicedate=item.invoicedate,
                    customerid=item.customerid,
                    isactive = item.isactive
                    
                });
            }
            return lstBill;
        }

        public ActionResult SaveBill(billing bill)
        {
            E_BILL bil = new E_BILL();
            bil.id = bill.id;
            bil.billno = bill.billno;
            bil.invoicedate = bill.invoicedate;
            bil.customerid = bill.customerid;
            bil.isactive = bill.isactive;
            billingBusiness bb = new billingBusiness();
            bb.SaveBill(bil);

            bill = new billing();
            List<E_BILL> lstentBill = new billingBusiness().ViewAllBill();
            bill.lstBilling = ConvertToModelBilling(lstentBill);
            return View("Index", bill);
        }

        public ActionResult DeleteBill(int id)
        {
            billingBusiness bb = new billingBusiness();
            bb.DeleteBill(id);


            List<E_BILL> lstentBill = new billingBusiness().ViewAllBill();
            billing bil = new billing();
            bil.lstBilling = ConvertToModelBilling(lstentBill);
            return View("Index", bil);
        }

        public ActionResult FindBillById(int id)
        {
            List<E_BILL> lstbil = new billingBusiness().ViewBillById(id);
            return View("Index", ConvertToModelBilling(lstbil)[0]);
        }

        public ActionResult ModelNull(billing lstBill)
        {
            return View("Index", new billing());
        }



        public ActionResult SearchBill(string billno, string invoicedate)
        {

            billingBusiness bb = new billingBusiness();
            List<E_BILL> listBill = bb.SearchBill(billno, invoicedate);
            billing bil = new billing();
            bil.lstBilling = ConvertToModelBilling(listBill);
            return View("Index", bil);
        }

    }
}
