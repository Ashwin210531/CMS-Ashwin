﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity;
using Business;
using CMS.Models;
namespace CMS.Controllers
{
    public class billingitemController : Controller
    {
        //
        // GET: /billingitem/

        public ActionResult Index()
        {
            billingitem bilItem = new billingitem();
            List<E_BillItem> lstentBillItem = new BillingItemBusiness().ViewAllBillItems();
            bilItem.lstBillItem = ConvertToModelBillingItem(lstentBillItem);
            return View(bilItem);
        }

        private List<billingitem> ConvertToModelBillingItem(List<E_BillItem> lstentBillItem)
        {
            List<billingitem> lstBillItem = new List<billingitem>();
            foreach (var item in lstentBillItem)
            {
                lstBillItem.Add(new billingitem
                {
                    id = item.Id,
                    billingid=item.Billingid,
                    itemid=item.Itemid,
                    qty=item.Qty,
                    price=item.Price,
                    uomid=item.Uomid,
                    isactive=item.Isactive

                });
            }
            return lstBillItem;
        }

        public ActionResult SaveBillItem(billingitem billItem)
        {
            E_BillItem bil = new E_BillItem();
            bil.Id = billItem.id;
            bil.Billingid = billItem.billingid;
            bil.Itemid = billItem.itemid;
            bil.Qty = billItem.qty;
            bil.Price = billItem.price;
            bil.Uomid = billItem.uomid;
            bil.Isactive = billItem.isactive;
            BillingItemBusiness bb = new BillingItemBusiness();
            bb.SaveBillingItem(bil);

            billItem = new billingitem();
            List<E_BillItem> lstentBillItem = new BillingItemBusiness().ViewAllBillItems();
            billItem.lstBillItem = ConvertToModelBillingItem(lstentBillItem);
            return View("Index", billItem);
        }

        public ActionResult DeleteBillItem(int id)
        {
            BillingItemBusiness bb = new BillingItemBusiness();
            bb.deleteBillingItem(id);


            List<E_BillItem> lstentBill = new BillingItemBusiness().ViewAllBillItems();
            billingitem bil = new billingitem();
            bil.lstBillItem = ConvertToModelBillingItem(lstentBill);
            return View("Index", bil);
        }

        public ActionResult FindBillItemById(int id)
        {
            List<E_BillItem> lstbil = new BillingItemBusiness().ViewBillItemById(id);
            return View("Index", ConvertToModelBillingItem(lstbil)[0]);
        }

        public ActionResult ModelNull(billingitem lstBill)
        {
            return View("Index", new billingitem());
        }



        public ActionResult SearchBillItem(int itemid, int qty)
        {

            BillingItemBusiness bb = new BillingItemBusiness();
            List<E_BillItem> listBill = bb.SearchBillItem(itemid,qty);
            billingitem bil = new billingitem();
            bil.lstBillItem = ConvertToModelBillingItem(listBill);
            return View("Index", bil);
        }

       

    }
}
