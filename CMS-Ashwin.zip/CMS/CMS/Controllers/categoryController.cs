﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity;
using Business;
using CMS.Models;

namespace CMS.Controllers
{
    public class categoryController : Controller
    {
        //
        // GET: /category/

        public ActionResult Index()
        {
            Category cat = new Category();
            List<E_Category> lstentCat = new CategoryBusiness().ViewCategories();
            cat.lstcategory = ConvertToModelCategory(lstentCat);
            return View(cat);
        }

        private List<Category> ConvertToModelCategory(List<E_Category> lstentCat)
        {
            List<Category> lstCat = new List<Category>();
            foreach (var item in lstentCat)
            {
                lstCat.Add(new Category
                {
                    id = item.Id,
                    categoryname=item.Categoryname,
                    categorycode=item.Categorycode,
                    isActive = item.IsActive
                });
            }
            return lstCat;
        }
        [HttpPost]
        public ActionResult SaveCategory(Category cat)
        {
            E_Category Cat = new E_Category();
            Cat.Id = cat.id;
            Cat.Categoryname = cat.categoryname;
            Cat.Categorycode = cat.categorycode;
            CategoryBusiness cb = new CategoryBusiness();
            cb.SaveCategory(Cat);

            cat = new Category();
            List<E_Category> lstentCat = new CategoryBusiness().ViewCategories();
            cat.lstcategory = ConvertToModelCategory(lstentCat);
            return View("Index", cat);
        }

        public ActionResult ModelNull(Category catlst)
        {
            return View("Index", new Category());
        }


        public ActionResult DeleteCategory(int id)
        {
            CategoryBusiness cb = new CategoryBusiness();
            cb.DeleteCategory(id);


            List<E_Category> lstentCat= new CategoryBusiness().ViewCategories();
            Category cat = new Category();
            cat.lstcategory = ConvertToModelCategory(lstentCat);
            return View("Index", cat);
        }

        public ActionResult FindCategoryById(int id)
        {
            List<E_Category> lstCat = new CategoryBusiness().ViewCategoriesById(id);
            return View("Index", ConvertToModelCategory(lstCat)[0]);
        }





        public ActionResult SearchCategory(string categoryname, string categorycode)
        {

            CategoryBusiness cb = new CategoryBusiness();
            List<E_Category> listCat = cb.SearchCategory(categoryname, categorycode);
            Category cat = new Category();
            cat.lstcategory = ConvertToModelCategory(listCat);
            return View("Index", cat);
        }

    }
}
