﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity;
using Business;
using CMS.Models;

namespace CMS.Controllers
{
    public class companyController : Controller
    {
        //
        // GET: /company/

        public ActionResult Index()
        {
            Company comp = new Company();
            List<E_Company> lstentCompany = new CompanyBusiness().getAllCompanies();
            comp.lstComp = ConvertToModelCompany(lstentCompany);
            return View(comp);
        }

        private List<Company> ConvertToModelCompany(List<E_Company> lstentCompany)
        {
            List<Company> lstComp = new List<Company>();
            foreach (var item in lstentCompany)
            {
                lstComp.Add(new Company
                {
                   id=item.Id,
                   companyName = item.CompanyName,
                   address = item.Address,
                   email = item.Address,
                   gstno = item.Gstno,
                   contactno = item.Contactno,
                   isActive = item.IsActive

                });
            }
            return lstComp;
        }

        [HttpPost]
        public ActionResult SaveCompany(Company comp)
        {
            E_Company ecomp = new E_Company();
            comp.id = ecomp.Id;
            comp.companyName = ecomp.CompanyName;
            comp.address = ecomp.Address;
            comp.gstno = ecomp.Gstno;
            comp.contactno = ecomp.Contactno;
            comp.isActive = ecomp.IsActive;
            CompanyBusiness cb = new CompanyBusiness();
            cb.SaveCompany(ecomp);

            comp = new Company();
            List<E_Company> lstentCompany = new CompanyBusiness().getAllCompanies();
            comp.lstComp = ConvertToModelCompany(lstentCompany);
            return View("Index", comp);
        }

        public ActionResult DeleteCompany(int id)
        {
            CompanyBusiness cb = new CompanyBusiness();
            cb.deleteCompany(id);

            List<E_Company> lstentComp = new CompanyBusiness().getAllCompanies();
            Company comp = new Company();
            comp.lstComp = ConvertToModelCompany(lstentComp);
            return View("Index", comp);
        }

        public ActionResult FindCompanyById(int id)
        {
            List<E_Company> lstComp = new CompanyBusiness().getCompanyByID(id);
            return View("Index", ConvertToModelCompany(lstComp)[0]);
        }

        public ActionResult ModelNull(Company lstComp)
        {
            return View("Index", new Company());
        }



        public ActionResult SearchCompanyByCompanyNameAndEmail(string companyname, string email)
        {

            CompanyBusiness cb = new CompanyBusiness();
            List<E_Company> listComp = cb.SearchCompany(companyname, email);
            Company com = new Company();
            com.lstComp = ConvertToModelCompany(listComp);
            return View("Index", com);
        }

    }
}
