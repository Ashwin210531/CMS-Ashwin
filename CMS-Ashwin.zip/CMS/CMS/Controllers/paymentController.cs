﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CMS.Models;
using Entity;
using Business;

namespace CMS.Controllers
{
    public class paymentController : Controller
    {
        //
        // GET: /payment/

        public ActionResult Index()
        {
            payment pay = new payment();
            List<e_payment> lstentPayment = new paymentBusiness().getAllPayments();
            pay.lstPay = ConvertToModelPayment(lstentPayment);
            return View(pay);
        }

        private List<payment> ConvertToModelPayment(List<e_payment> lstentPayment)
        {
            List<payment> lstPay = new List<payment>();
            foreach (var item in lstentPayment)
            {
                lstPay.Add(new payment
                {
                    id = item.id,
                    billingid = item.billingid,
                    paidamount = item.paidamount,
                    paiddate = item.paiddate,
                    paymentrefno = item.paymentrefno,
                    isactive = item.isactive

                });
            }
            return lstPay;
        }
        [HttpPost]
        public ActionResult SavePayment(payment pay)
        {
            e_payment e_pay = new e_payment();
            e_pay.billingid = pay.billingid;
            e_pay.paidamount = pay.paidamount;
            e_pay.paiddate = pay.paiddate;
            e_pay.paymentrefno = pay.paymentrefno;
            e_pay.isactive = pay.isactive;
            paymentBusiness sb = new paymentBusiness();
            sb.SavePayment(e_pay);

            pay = new payment();
            List<e_payment> lstentPay = new paymentBusiness().getAllPayments();
            pay.lstPay = ConvertToModelPayment(lstentPay);
            return View("Index", pay);
        }

        public ActionResult DeletePayment(int id)
        {
            paymentBusiness pb = new paymentBusiness();
            pb.deletePayment(id);


            List<e_payment> lstentPay = new paymentBusiness().getAllPayments();
            payment pay = new payment();
            pay.lstPay = ConvertToModelPayment(lstentPay);
            return View("Index", pay);
        }
        public ActionResult FindPaymentById(int id)
        {
            List<e_payment> lstPaym = new paymentBusiness().getPaymentById(id);
            return View("Index", ConvertToModelPayment(lstPaym)[0]);
        }
        public ActionResult ModelNull(payment lstpay)
        {
            return View("Index", new payment());
        }
        public ActionResult SearchPayment(int paymentrefno)
        {

            paymentBusiness pb = new paymentBusiness();
            List<e_payment> listPay = pb.SearchPayment(paymentrefno);
            payment pay = new payment();
            pay.lstPay = ConvertToModelPayment(listPay);
            return View("Index", pay);
        }

    }
}
