﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
     public class billingitem
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "BillingID")]
        public int billingid { get; set; }
        [Required]
        [Display(Name = "ItemID")]
        public int itemid { get; set; }
        [Required]
        [Display(Name = "Quantity")]
        public int qty { get; set; }
        [Required]
        [Display(Name = "Price")]
        public float price { get; set; }
        [Required]
        [Display(Name = "UOMID")]
        public int uomid { get; set; }
        [Required]
        [Display(Name = "IsActive")]
        public bool isactive { get; set; }
        public List<billingitem> lstBillItem { get; set; }
  
    }
}
