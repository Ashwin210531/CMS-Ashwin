﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class Category
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "CategoryName")]
        public string categoryname { get; set; }
        [Required]
        [Display(Name = "CategoryCode")]
        public string categorycode { get; set; }
        [Required]
        [Display(Name = "ISActive")]
        public bool isActive { get; set; }
        public List<Category> lstcategory { get; set; }
   
    }
}
