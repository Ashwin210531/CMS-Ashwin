﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class Company
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "CompanyName")]
        public string companyName { get; set; }
        [Required]
        [Display(Name = "Address")]
        public string address { get; set; }
        [Required]
        [Display(Name = "Email")]
        public string email { get; set; }
        [Required]
        [Display(Name = "GSTNo")]
        public long gstno { get; set; }
        [Required]
        [Display(Name = "ContactNo")]
        public string contactno { get; set; }
        [Required]
        [Display(Name = "IsActive ")]
        public bool isActive { get; set; }
        public List<Company> lstComp { get; set; }

    }
}
