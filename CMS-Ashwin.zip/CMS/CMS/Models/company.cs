﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class company
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "Company Name")]
        public string companyName { get; set; }
        [Required]
        [Display(Name = "Address")]
        public string address { get; set; }
        [Required]
        [Display(Name = "E-mail")]
        public string email { get; set; }
        [Required]
        [Display(Name = "GST No")]
        public long gstno { get; set; }
        [Required]
        [Display(Name = "Contact No")]
        public string contactno { get; set; }
        [Required]
        [Display(Name = "Is Active ")]
        public bool isActive { get; set; }
        public List<company> lstComp { get; set; }

    }
}
