﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class customer
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "Customer Name")]
        public string customername { get; set; }
        [Required]
        [Display(Name = "Customer Code")]
        public string customercode { get; set; }
        [Required]
        [Display(Name = "Company Name")]
        public string companyname { get; set; }
        [Required]
        [Display(Name = "Address")]
        public string address { get; set; }
        [Required]
        [Display(Name = "GST Number")]
        public string gstno { get; set; }
        [Required]
        [Display(Name = "Gender")]
        public string gender { get; set; }
        [Required]
        [Display(Name = "Is Active")]
        public bool isactive { get; set; }
        public List<customer> lstCust { get; set; }
    }
}
