﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CMS.Models
{
    public class user
    {
        
        public int id { get; set; }
        [Required]
        [Display(Name = "User Name")]
        public string username { get; set; }
        [Required]
        [Display(Name = "Password")]
        public string password { get; set; }
        [Required]
        [Display(Name = "User Role")]
        public string userRole { get; set; }
        [Required]
        [Display(Name = "IS Active")]
        public bool isActive { get; set; }
        
        public List<user> lstUsers { get; set; }
    }
}
