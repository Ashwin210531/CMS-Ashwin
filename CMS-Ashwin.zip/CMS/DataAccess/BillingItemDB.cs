﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class BillingItemDB
    {
        long result = 0;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);

        public long DeleteBillItem(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteBillingItem;
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<E_BillItem> ViewAllBillItems()
        {
            List<E_BillItem> lstBillItem = new List<E_BillItem>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllBillingItems;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_BillItem billItem = new E_BillItem();
                        billItem.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        billItem.Billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        billItem.Itemid = Convert.ToInt32(reader.GetValue(2).ToString());
                        billItem.Qty = Convert.ToInt32(reader.GetValue(3).ToString());
                        billItem.Price = Convert.ToInt32(reader.GetValue(4).ToString());
                        billItem.Uomid = Convert.ToInt32(reader.GetValue(5).ToString());
                        billItem.Isactive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstBillItem.Add(billItem);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBillItem;
        }

        public List<E_BillItem> ViewBillItemById(int id)
        {
            List<E_BillItem> lstBillItem = new List<E_BillItem>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetBillingItemById;
                    cmd.Parameters.AddWithValue("@id",id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_BillItem billItem = new E_BillItem();
                        billItem.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        billItem.Billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        billItem.Itemid = Convert.ToInt32(reader.GetValue(2).ToString());
                        billItem.Qty = Convert.ToInt32(reader.GetValue(3).ToString());
                        billItem.Price = Convert.ToInt32(reader.GetValue(4).ToString());
                        billItem.Uomid = Convert.ToInt32(reader.GetValue(5).ToString());
                        billItem.Isactive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstBillItem.Add(billItem);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBillItem;
        }


        public long InsertBillItem(E_BillItem b_item)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertBillingItem;
                    //cmd.Parameters.AddWithValue("@ID", b_item.id);
                    cmd.Parameters.AddWithValue("@billingid", b_item.Billingid);
                    cmd.Parameters.AddWithValue("@itemid", b_item.Itemid);
                    cmd.Parameters.AddWithValue("@qty", b_item.Qty);
                    cmd.Parameters.AddWithValue("@price", b_item.Price);
                    cmd.Parameters.AddWithValue("@uomid", b_item.Uomid);
                    cmd.Parameters.AddWithValue("@isactive", b_item.Isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateBillItem(E_BillItem b_item)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateBillingItem;
                    cmd.Parameters.AddWithValue("@id", b_item.Id);
                    cmd.Parameters.AddWithValue("@billingid", b_item.Billingid);
                    cmd.Parameters.AddWithValue("@itemid", b_item.Itemid);
                    cmd.Parameters.AddWithValue("@qty", b_item.Qty);
                    cmd.Parameters.AddWithValue("@price", b_item.Price);
                    cmd.Parameters.AddWithValue("@isactive", b_item.Uomid);
                    cmd.Parameters.AddWithValue(" ", b_item.Isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }
        public List<E_BillItem> SearchBillItem(int itemid,int qty)
        {
            List<E_BillItem> lstBillItem = new List<E_BillItem>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchBillItemByitemAndQty;
                    cmd.Parameters.AddWithValue("@itemid", itemid);
                    cmd.Parameters.AddWithValue("@qty", qty);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_BillItem billItem = new E_BillItem();
                        billItem.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        billItem.Billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        billItem.Itemid = Convert.ToInt32(reader.GetValue(2).ToString());
                        billItem.Qty = Convert.ToInt32(reader.GetValue(3).ToString());
                        billItem.Price = Convert.ToInt32(reader.GetValue(4).ToString());
                        billItem.Uomid = Convert.ToInt32(reader.GetValue(5).ToString());
                        billItem.Isactive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstBillItem.Add(billItem);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBillItem;
        }
    }

}
