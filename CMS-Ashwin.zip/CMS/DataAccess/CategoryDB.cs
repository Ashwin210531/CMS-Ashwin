﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class CategoryDB
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);

        public long DeleteCategory(int id)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteCategory;
                    cmd.Parameters.AddWithValue("@ID", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_category> GetAllCategories()
        {
            List<e_category> lstCat = new List<e_category>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_ReadAllCategories;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_category cat = new e_category();
                        cat.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cat.categoryname = reader.GetValue(1).ToString();
                        cat.categorycode = reader.GetValue(2).ToString();
                        cat.isActive = Convert.ToBoolean(reader.GetValue(3).ToString() == "0" ? true : false);
                        lstCat.Add(cat);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCat;
        }


        public List<e_category> GetCategorybyID(int id)
        {
            List<e_category> lstCat = new List<e_category>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetCategoryById;
                    cmd.Parameters.AddWithValue("@id", id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_category cat = new e_category();
                        cat.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cat.categoryname = reader.GetValue(1).ToString();
                        cat.categorycode = reader.GetValue(2).ToString();
                        cat.isActive = Convert.ToBoolean(reader.GetValue(3).ToString() == "1" ? true : false);
                        lstCat.Add(cat);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCat;
        }

        public List<e_category> SearchCategory(string categoryname,string categorycode)
        {
            List<e_category> lstCat = new List<e_category>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchByCategoryNameAndCode;
                    cmd.Parameters.AddWithValue("@categoryname", categoryname);
                    cmd.Parameters.AddWithValue("@categorycode", categorycode);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_category cat = new e_category();
                        cat.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cat.categoryname = reader.GetValue(1).ToString();
                        cat.categorycode = reader.GetValue(2).ToString();
                        cat.isActive = Convert.ToBoolean(reader.GetValue(3).ToString() == "1" ? true : false);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCat;
        }

        public long InsertCategory(e_category cat)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertCategory;
                    //cmd.Parameters.AddWithValue("@ID", cat.id);
                    cmd.Parameters.AddWithValue("@categoryname", cat.categoryname);
                    cmd.Parameters.AddWithValue("@categorycode", cat.categorycode);
                    cmd.Parameters.AddWithValue("@IsActive", cat.isActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateCategory(e_category cat)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateCategory;
                    cmd.Parameters.AddWithValue("@ID", cat.id);
                    cmd.Parameters.AddWithValue("@categoryname", cat.categoryname);
                    cmd.Parameters.AddWithValue("@categorycode", cat.categorycode);
                    cmd.Parameters.AddWithValue("@IsActive", cat.isActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }
    }
}
