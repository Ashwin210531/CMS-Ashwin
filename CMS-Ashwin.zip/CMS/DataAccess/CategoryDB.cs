﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class CategoryDB
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);

        public long DeleteCategory(int id)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteCategory;
                    cmd.Parameters.AddWithValue("@ID", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<E_Category>ViewCategories()
        {
            List<E_Category> lstCat = new List<E_Category>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_ReadAllCategories;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_Category cat = new E_Category();
                        cat.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cat.Categoryname = reader.GetValue(1).ToString();
                        cat.Categorycode = reader.GetValue(2).ToString();
                        cat.IsActive = Convert.ToBoolean(reader.GetValue(3).ToString() == "0" ? true : false);
                        lstCat.Add(cat);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCat;
        }


        public List<E_Category> ViewCategoriesById(int id)
        {
            List<E_Category> lstCat = new List<E_Category>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetCategoryById;
                    cmd.Parameters.AddWithValue("@id", id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_Category cat = new E_Category();
                        cat.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cat.Categoryname = reader.GetValue(1).ToString();
                        cat.Categorycode = reader.GetValue(2).ToString();
                        cat.IsActive = Convert.ToBoolean(reader.GetValue(3).ToString() == "1" ? true : false);
                        lstCat.Add(cat);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCat;
        }

        public List<E_Category> SearchCategory(string categoryname,string categorycode)
        {
            List<E_Category> lstCat = new List<E_Category>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchByCategoryNameAndCode;
                    cmd.Parameters.AddWithValue("@categoryname", categoryname);
                    cmd.Parameters.AddWithValue("@categorycode", categorycode);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_Category cat = new E_Category();
                        cat.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cat.Categoryname = reader.GetValue(1).ToString();
                        cat.Categorycode = reader.GetValue(2).ToString();
                        cat.IsActive = Convert.ToBoolean(reader.GetValue(3).ToString() == "1" ? true : false);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCat;
        }

        public long InsertCategory(E_Category cat)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertCategory;
                    cmd.Parameters.AddWithValue("@categoryname", cat.Categoryname);
                    cmd.Parameters.AddWithValue("@categorycode", cat.Categorycode);
                    cmd.Parameters.AddWithValue("@IsActive", cat.IsActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateCategory(E_Category cat)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateCategory;
                    cmd.Parameters.AddWithValue("@ID", cat.Id);
                    cmd.Parameters.AddWithValue("@categoryname", cat.Categoryname);
                    cmd.Parameters.AddWithValue("@categorycode", cat.Categorycode);
                    cmd.Parameters.AddWithValue("@IsActive", cat.IsActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }
    }
}
