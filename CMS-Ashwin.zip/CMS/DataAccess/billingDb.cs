﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;

namespace DataAccess
{
    public class BillDb
    {
        SqlConnection sqlCon = new SqlConnection( ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);
        public long DeleteBill(int id)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.STORED_PROCEDURE_DELETE_BILLING;
                    
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<E_BILL> ViewAllBill()
        {
            List<E_BILL> lstBill = new List<E_BILL>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllBillings;
                  
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_BILL bill = new E_BILL();
                        bill.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        bill.Billno = reader.GetValue(1).ToString();
                        bill.InvoiceDate = reader.GetValue(2).ToString();
                        bill.CustomerId =Convert.ToInt32( reader.GetValue(3).ToString());
                        bill.IsActive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstBill.Add(bill);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBill;
        }

        public List<E_BILL> ViewBillById(int id)
        {
            List<E_BILL> lstBill = new List<E_BILL>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetBillingById;
                    cmd.Parameters.AddWithValue("@id", id);
                    
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_BILL bill = new E_BILL();
                        bill.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        bill.Billno = reader.GetValue(1).ToString();
                        bill.InvoiceDate = reader.GetValue(2).ToString();
                        bill.CustomerId = Convert.ToInt32(reader.GetValue(3).ToString());
                        bill.IsActive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstBill.Add(bill);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBill;
        }


        public long InsertBill(E_BILL bill)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertBilling;
                    
                    cmd.Parameters.AddWithValue("@billno", bill.Billno);
                    cmd.Parameters.AddWithValue("@invoicedate", bill.InvoiceDate);
                    cmd.Parameters.AddWithValue("@customerid", bill.CustomerId);
                    cmd.Parameters.AddWithValue("@isactive", bill.IsActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateBill(E_BILL bill)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateBilling;
                    cmd.Parameters.AddWithValue("@ID", bill.Id);
                    cmd.Parameters.AddWithValue("@billno", bill.Billno);
                    cmd.Parameters.AddWithValue("@invoicedate", bill.InvoiceDate);
                    cmd.Parameters.AddWithValue("@customerid", bill.CustomerId);
                    cmd.Parameters.AddWithValue("@isactive", bill.IsActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<E_BILL> SearchBill(string billno,string invoicedate)
        {
            List<E_BILL> lstBill = new List<E_BILL>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchByBillNoAndInvoiceDate;
                    cmd.Parameters.AddWithValue("@billno", billno);
                    cmd.Parameters.AddWithValue("@invoicedate", invoicedate);
                    
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_BILL bill = new E_BILL();
                        bill.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        bill.Billno = reader.GetValue(1).ToString();
                        bill.InvoiceDate = reader.GetValue(2).ToString();
                        bill.CustomerId = Convert.ToInt32(reader.GetValue(3).ToString());
                        bill.IsActive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstBill.Add(bill);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBill;
        }


    }
}
