﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;

namespace DataAccess
{
    public class companyDB
    {
        long result;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);

        public List<E_Company> GetAllCompanies()
        {
            List<E_Company> lstComp = new List<E_Company>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllCompanies;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_Company comp = new E_Company();
                        comp.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        comp.CompanyName = reader.GetValue(1).ToString();
                        comp.Address = reader.GetValue(2).ToString();
                        comp.Email = reader.GetValue(3).ToString();
                        comp.Gstno = Convert.ToInt32(reader.GetValue(4).ToString());
                        comp.Contactno = reader.GetValue(5).ToString();
                        comp.IsActive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstComp.Add(comp);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstComp;
        }

        public List<E_Company> GetCompanyByID(int id)
        {
            List<E_Company> lstComp = new List<E_Company>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetCompanyById;
                    cmd.Parameters.AddWithValue("@id",id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_Company comp = new E_Company();
                        comp.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        comp.CompanyName = reader.GetValue(1).ToString();
                        comp.Address = reader.GetValue(2).ToString();
                        comp.Email = reader.GetValue(3).ToString();
                        comp.Gstno = Convert.ToInt32(reader.GetValue(4).ToString());
                        comp.Contactno = reader.GetValue(5).ToString();
                        comp.IsActive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstComp.Add(comp);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstComp;
        }

        public long DeleteCompany(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_deleteCompany;
                    cmd.Parameters.AddWithValue("@ID", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long InsertCompany(E_Company com)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertCompany;
                   // cmd.Parameters.AddWithValue("@ID", com.id);
                    cmd.Parameters.AddWithValue("@companyname", com.companyName);
                    cmd.Parameters.AddWithValue("@address", com.address);
                    cmd.Parameters.AddWithValue("@email", com.email);
                    cmd.Parameters.AddWithValue("@gstno", com.gstno);
                    cmd.Parameters.AddWithValue("@contactno", com.contactno);
                    cmd.Parameters.AddWithValue("@isactive", com.isActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateCompany(E_Company com)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandText = Constants.SP_UpdateCompany;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", com.Id);
                    cmd.Parameters.AddWithValue("@companyname", com.CompanyName);
                    cmd.Parameters.AddWithValue("@address", com.Address);
                    cmd.Parameters.AddWithValue("@email", com.Email);
                    cmd.Parameters.AddWithValue("@gstno", com.Gstno);
                    cmd.Parameters.AddWithValue("@contactno", com.Contactno);
                    cmd.Parameters.AddWithValue("@isactive", com.IsActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<E_Company> SearchCompany(string companyname,string email)
        {
            List<E_Company> lstComp = new List<E_Company>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchCompanyByCompanyNameAndEmail;
                    cmd.Parameters.AddWithValue("@companyname",companyname);
                    cmd.Parameters.AddWithValue("@email", email);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        E_Company comp = new E_Company();
                        comp.Id = Convert.ToInt32(reader.GetValue(0).ToString());
                        comp.CompanyName = reader.GetValue(1).ToString();
                        comp.Address = reader.GetValue(2).ToString();
                        comp.Email = reader.GetValue(3).ToString();
                        comp.Gstno = Convert.ToInt32(reader.GetValue(4).ToString());
                        comp.Contactno = reader.GetValue(5).ToString();
                        comp.IsActive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstComp.Add(comp);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstComp;
        }
    }

}
