﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class itemDB
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);


        public long DeleteItem(int id)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteItem;
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public List<e_item> GetAllItems()
        {
            List<e_item> lstItem = new List<e_item>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllItems;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_item item = new e_item();
                        item.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        item.categoryid =Convert.ToInt32( reader.GetValue(1).ToString());
                        item.subcategoryid = Convert.ToInt32(reader.GetValue(2).ToString());
                        item.productname = reader.GetValue(3).ToString();
                        item.productcode = reader.GetValue(4).ToString();
                        item.isactive = Convert.ToBoolean(reader.GetValue(5).ToString() == "1" ? true : false);
                        lstItem.Add(item);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstItem;
        }



        public List<e_item> GetItemByID(int id)
        {
            List<e_item> lstItem = new List<e_item>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetItemById;
                    cmd.Parameters.AddWithValue("@id",id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_item item = new e_item();
                        item.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        item.categoryid = Convert.ToInt32(reader.GetValue(1).ToString());
                        item.subcategoryid = Convert.ToInt32(reader.GetValue(2).ToString());
                        item.productname = reader.GetValue(3).ToString();
                        item.productcode = reader.GetValue(4).ToString();
                        item.isactive = Convert.ToBoolean(reader.GetValue(5).ToString() == "1" ? true : false);
                        lstItem.Add(item);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstItem;
        }



        public long InsertItem(e_item item)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertItem;
                    cmd.Parameters.AddWithValue("@id", item.id);
                    cmd.Parameters.AddWithValue("@categoryid", item.categoryid);
                    cmd.Parameters.AddWithValue("@subcategoryid", item.subcategoryid);
                    cmd.Parameters.AddWithValue("@productname", item.productname);
                    cmd.Parameters.AddWithValue("@productcode", item.productcode);
                    cmd.Parameters.AddWithValue("@isactive", item.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public long UpdateItem(e_item item)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateItem;
                    cmd.Parameters.AddWithValue("@id", item.id);
                    cmd.Parameters.AddWithValue("@categoryid", item.categoryid);
                    cmd.Parameters.AddWithValue("@subcategoryid", item.subcategoryid);
                    cmd.Parameters.AddWithValue("@productname", item.productname);
                    cmd.Parameters.AddWithValue("@productcode", item.productcode);
                    cmd.Parameters.AddWithValue("@isactive", item.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_item> SearchItemByproductnameAndCode(string productname,string productcode)
        {
            List<e_item> lstItem = new List<e_item>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchItemByproductnameAndCode;
                    cmd.Parameters.AddWithValue("@productname", productname);
                    cmd.Parameters.AddWithValue("@productcode", productcode);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_item item = new e_item();
                        item.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        item.categoryid = Convert.ToInt32(reader.GetValue(1).ToString());
                        item.subcategoryid = Convert.ToInt32(reader.GetValue(2).ToString());
                        item.productname = reader.GetValue(3).ToString();
                        item.productcode = reader.GetValue(4).ToString();
                        item.isactive = Convert.ToBoolean(reader.GetValue(5).ToString() == "1" ? true : false);
                        lstItem.Add(item);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstItem;
        }
    }

}
