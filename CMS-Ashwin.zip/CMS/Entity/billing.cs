﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class E_BILL
    {
        public int Id { get; set; }
        public string Billno { get; set; }
        public string InvoiceDate { get; set; }
        public int CustomerId { get; set; }
        public bool IsActive { get; set; }
    }
}
