﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
     public class E_BillItem
    {
        public int Id { get; set; }
        public int Billingid { get; set; }
        public int Itemid { get; set; }
        public int Qty { get; set; }
        public float Price { get; set; }
        public int Uomid { get; set; }
        public bool Isactive { get; set; }
  
    }
}
