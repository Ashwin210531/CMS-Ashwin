﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class e_customer
    {
        public int id { get; set; }
        public string customername { get; set; }
        public string customercode { get; set; }
        public string companyname { get; set; }
        public string address { get; set; }
        public string gstno { get; set; }
        public string gender { get; set; }
        public bool isactive { get; set; }
    }
}
