﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using DataAccess;
using Entity;

namespace Business
{
    public class CategoryBusiness
    {
        CategoryDB db = new CategoryDB();


        public void DeleteCategory(int id)
        {
            db.DeleteCategory(id);
        }


        public void UpdateCategory(e_category cat)
        {
            db.UpdateCategory(cat);
        }


        public void SaveCategory(e_category cat)
        {
            if (cat.id > 0)
            {
                db.UpdateCategory(cat);
            }
            else
            {
                db.InsertCategory(cat);
            }
        }


        public List<e_category> GetAllCategories()
        {
            return db.GetAllCategories();
        }


        public List<e_category> GetCategoryById(int id)
        {
            return db.GetCategorybyID(id);
        }

        public List<e_category> SearchCategory(string categoryname, string categorycode)
        {
            return db.SearchCategory(categoryname,categorycode);
        }
    }
}
