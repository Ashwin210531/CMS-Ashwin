﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CMS.Models;
using Entity;
using Business;

namespace CMS.Controllers
{
    public class UserController : Controller
    {
       
        //
        // GET: /user/

        public ActionResult Index()
        {
            user usr = new user();
            List<e_user> lstentUsers = new userBusiness().getAllUsers();
            usr.lstUsers = ConvertToModelUser(lstentUsers);
            return View(usr);
        }

        private List<user> ConvertToModelUser(List<e_user> lstentUsers)
        {
            List<user> lstUser = new List<user>();
            foreach (var item in lstentUsers)
            {
                lstUser.Add(new user
                {
                    username = item.username,
                    password = item.password,
                    id = item.id,
                    isActive = item.isActive,
                    userRole = item.userRole,
                });
            }
            return lstUser;
        }


        [HttpPost]
        public ActionResult SaveUser(user user)
        {
            e_user usr = new e_user();
            usr.id = user.id;
            usr.username = user.username;
            usr.password = user.password;
            usr.userRole = user.userRole;
            usr.isActive = user.isActive;
            userBusiness ub = new userBusiness();
            ub.SaveUser(usr);

            user = new user();
            List<e_user> lstentUsers = new userBusiness().getAllUsers();
            user.lstUsers = ConvertToModelUser(lstentUsers);
            return View("Index", user);
        }


        public ActionResult DeleteUser(int id)
        {
            userBusiness ub = new userBusiness();
            ub.deleteUser(id);


            List<e_user> lstentUsers = new userBusiness().getAllUsers();
            user usr = new user();
            usr.lstUsers = ConvertToModelUser(lstentUsers);
            return View("Index", usr);
        }

        public ActionResult FindUserById(int id)
        {
            List<e_user> lstUsr = new userBusiness().getUserById(id);
            return View("Index", ConvertToModelUser(lstUsr)[0]);
        }

        public ActionResult ModelNull(user usrlst)
        {
            return View("Index", new user());
        }
        
        

        public ActionResult SearchUserByNameAndRole( string username,string userRole) {
           
            userBusiness ub = new userBusiness();
            List<e_user> listUsrs = ub.SearchUser(username, userRole);
            user usr = new user();
            usr.lstUsers = ConvertToModelUser(listUsrs);
            return View("Index", usr);
        }
    }
}
