﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class billing
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "Bill No")]
        public string billno { get; set; }
        [Required]
        [Display(Name = "Invoice Date ")]
        public string invoicedate { get; set; }
        [Required]
        [Display(Name = "Customer ID")]
        public int customerid { get; set; }
        [Required]
        [Display(Name = "IsActive")]
        public bool isactive { get; set; }
        public List<billing> lstBilling { get; set; }
    }
}
