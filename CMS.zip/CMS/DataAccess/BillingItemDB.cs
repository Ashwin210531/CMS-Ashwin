﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class BillingItemDB
    {
        long result = 0;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);

        public long DeleteBillingItem(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteBillingItem;
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_billingitem> GetAllBillingitems()
        {
            List<e_billingitem> lstBillItem = new List<e_billingitem>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllBillingItems;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_billingitem billItem = new e_billingitem();
                        billItem.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        billItem.billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        billItem.itemid = Convert.ToInt32(reader.GetValue(2).ToString());
                        billItem.qty = Convert.ToInt32(reader.GetValue(3).ToString());
                        billItem.price = Convert.ToInt32(reader.GetValue(4).ToString());
                        billItem.uomid = Convert.ToInt32(reader.GetValue(5).ToString());
                        billItem.isactive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstBillItem.Add(billItem);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBillItem;
        }

        public List<e_billingitem> GetBillingitemByID(int id)
        {
            List<e_billingitem> lstBillItem = new List<e_billingitem>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetBillingItemById;
                    cmd.Parameters.AddWithValue("@id",id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_billingitem billItem = new e_billingitem();
                        billItem.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        billItem.billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        billItem.itemid = Convert.ToInt32(reader.GetValue(2).ToString());
                        billItem.qty = Convert.ToInt32(reader.GetValue(3).ToString());
                        billItem.price = Convert.ToInt32(reader.GetValue(4).ToString());
                        billItem.uomid = Convert.ToInt32(reader.GetValue(5).ToString());
                        billItem.isactive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstBillItem.Add(billItem);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBillItem;
        }


        public long InsertBillingItem(e_billingitem b_item)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertBillingItem;
                    //cmd.Parameters.AddWithValue("@ID", b_item.id);
                    cmd.Parameters.AddWithValue("@billingid", b_item.billingid);
                    cmd.Parameters.AddWithValue("@itemid", b_item.itemid);
                    cmd.Parameters.AddWithValue("@qty", b_item.qty);
                    cmd.Parameters.AddWithValue("@price", b_item.price);
                    cmd.Parameters.AddWithValue("@uomid", b_item.uomid);
                    cmd.Parameters.AddWithValue("@isactive", b_item.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateBillingItem(e_billingitem b_item)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateBillingItem;
                    cmd.Parameters.AddWithValue("@id", b_item.id);
                    cmd.Parameters.AddWithValue("@billingid", b_item.billingid);
                    cmd.Parameters.AddWithValue("@itemid", b_item.itemid);
                    cmd.Parameters.AddWithValue("@qty", b_item.qty);
                    cmd.Parameters.AddWithValue("@price", b_item.price);
                    cmd.Parameters.AddWithValue("@isactive", b_item.uomid);
                    cmd.Parameters.AddWithValue(" ", b_item.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }
        public List<e_billingitem> SearchBillItem(int itemid,int qty)
        {
            List<e_billingitem> lstBillItem = new List<e_billingitem>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchBillItemByitemAndQty;
                    cmd.Parameters.AddWithValue("@itemid", itemid);
                    cmd.Parameters.AddWithValue("@qty", qty);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_billingitem billItem = new e_billingitem();
                        billItem.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        billItem.billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        billItem.itemid = Convert.ToInt32(reader.GetValue(2).ToString());
                        billItem.qty = Convert.ToInt32(reader.GetValue(3).ToString());
                        billItem.price = Convert.ToInt32(reader.GetValue(4).ToString());
                        billItem.uomid = Convert.ToInt32(reader.GetValue(5).ToString());
                        billItem.isactive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstBillItem.Add(billItem);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBillItem;
        }
    }

}
