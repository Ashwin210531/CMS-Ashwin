﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class CustomerDB
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);


        public long DeleteCustomer(int id)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteCustomer;
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public List<e_customer> GetAllCustomers()
        {
            List<e_customer> lstCust = new List<e_customer>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllCustomers;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_customer cust = new e_customer();
                        cust.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cust.customername = reader.GetValue(1).ToString();
                        cust.customercode = reader.GetValue(2).ToString();
                        cust.companyname = reader.GetValue(3).ToString();
                        cust.address = reader.GetValue(4).ToString();
                        cust.gstno = reader.GetValue(5).ToString();
                        cust.gender = reader.GetValue(6).ToString();
                        cust.isactive = Convert.ToBoolean(reader.GetValue(7).ToString() == "1" ? true : false);
                        lstCust.Add(cust);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCust;
        }


        public List<e_customer> GetCustomerById(int id)
        {
            List<e_customer> lstCust = new List<e_customer>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetCustomerById;
                    cmd.Parameters.AddWithValue("@id",id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_customer cust = new e_customer();
                        cust.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cust.customername = reader.GetValue(1).ToString();
                        cust.customercode = reader.GetValue(2).ToString();
                        cust.companyname = reader.GetValue(3).ToString();
                        cust.address = reader.GetValue(4).ToString();
                        cust.gstno = reader.GetValue(5).ToString();
                        cust.gender = reader.GetValue(6).ToString();
                        cust.isactive = Convert.ToBoolean(reader.GetValue(7).ToString() == "1" ? true : false);
                        lstCust.Add(cust);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCust;
        }


        public long InsertCustomer(e_customer cust)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertCustomer;
                   // cmd.Parameters.AddWithValue("@id", cust.id);
                    cmd.Parameters.AddWithValue("@customername", cust.customername);
                    cmd.Parameters.AddWithValue("@customercode", cust.customercode);
                    cmd.Parameters.AddWithValue("@companyname", cust.companyname);
                    cmd.Parameters.AddWithValue("@address", cust.address);
                    cmd.Parameters.AddWithValue("@gstno", cust.gstno);
                    cmd.Parameters.AddWithValue("@gender", cust.gender);
                    cmd.Parameters.AddWithValue("@isactive", cust.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public long UpdateCustomer(e_customer cust)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateCustomer;
                    cmd.Parameters.AddWithValue("@id", cust.id);
                    cmd.Parameters.AddWithValue("@customername", cust.customername);
                    cmd.Parameters.AddWithValue("@customercode", cust.customercode);
                    cmd.Parameters.AddWithValue("@companyname", cust.companyname);
                    cmd.Parameters.AddWithValue("@address", cust.address);
                    cmd.Parameters.AddWithValue("@gstno", cust.gstno);
                    cmd.Parameters.AddWithValue("@gender", cust.gender);
                    cmd.Parameters.AddWithValue("@isactive", cust.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }
        public List<e_customer> SearchByCustomerNameAndCompanyName(string customername, string companyname)
        {
            List<e_customer> lstCust = new List<e_customer>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchByCustomerNameAndCompanyName;
                    cmd.Parameters.AddWithValue("@customername",customername);
                    cmd.Parameters.AddWithValue("@companyname", companyname);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_customer cust = new e_customer();
                        cust.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        cust.customername = reader.GetValue(1).ToString();
                        cust.customercode = reader.GetValue(2).ToString();
                        cust.companyname = reader.GetValue(3).ToString();
                        cust.address = reader.GetValue(4).ToString();
                        cust.gstno = reader.GetValue(5).ToString();
                        cust.gender = reader.GetValue(6).ToString();
                        cust.isactive = Convert.ToBoolean(reader.GetValue(7).ToString() == "1" ? true : false);
                        lstCust.Add(cust);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstCust;
        }
    }

}
