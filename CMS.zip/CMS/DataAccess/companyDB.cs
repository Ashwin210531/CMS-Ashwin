﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;

namespace DataAccess
{
    public class companyDB
    {
        long result;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);

        public List<e_company> GetAllCompanies()
        {
            List<e_company> lstComp = new List<e_company>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllCompanies;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_company comp = new e_company();
                        comp.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        comp.companyName = reader.GetValue(1).ToString();
                        comp.address = reader.GetValue(2).ToString();
                        comp.email = reader.GetValue(3).ToString();
                        comp.gstno = Convert.ToInt32(reader.GetValue(4).ToString());
                        comp.contactno = reader.GetValue(5).ToString();
                        comp.isActive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstComp.Add(comp);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstComp;
        }

        public List<e_company> GetCompanyByID(int id)
        {
            List<e_company> lstComp = new List<e_company>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetCompanyById;
                    cmd.Parameters.AddWithValue("@id",id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_company comp = new e_company();
                        comp.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        comp.companyName = reader.GetValue(1).ToString();
                        comp.address = reader.GetValue(2).ToString();
                        comp.email = reader.GetValue(3).ToString();
                        comp.gstno = Convert.ToInt32(reader.GetValue(4).ToString());
                        comp.contactno = reader.GetValue(5).ToString();
                        comp.isActive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstComp.Add(comp);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstComp;
        }

        public long DeleteCompany(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_deleteCompany;
                    cmd.Parameters.AddWithValue("@ID", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long InsertCompany(e_company com)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertCompany;
                   // cmd.Parameters.AddWithValue("@ID", com.id);
                    cmd.Parameters.AddWithValue("@companyname", com.companyName);
                    cmd.Parameters.AddWithValue("@address", com.address);
                    cmd.Parameters.AddWithValue("@email", com.email);
                    cmd.Parameters.AddWithValue("@gstno", com.gstno);
                    cmd.Parameters.AddWithValue("@contactno", com.contactno);
                    cmd.Parameters.AddWithValue("@isactive", com.isActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateCompany(e_company com)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandText = Constants.SP_UpdateCompany;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", com.id);
                    cmd.Parameters.AddWithValue("@companyname", com.companyName);
                    cmd.Parameters.AddWithValue("@address", com.address);
                    cmd.Parameters.AddWithValue("@email", com.email);
                    cmd.Parameters.AddWithValue("@gstno", com.gstno);
                    cmd.Parameters.AddWithValue("@contactno", com.contactno);
                    cmd.Parameters.AddWithValue("@isactive", com.isActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_company> SearchCompany(string companyname,string email)
        {
            List<e_company> lstComp = new List<e_company>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchCompanyByCompanyNameAndEmail;
                    cmd.Parameters.AddWithValue("@companyname",companyname);
                    cmd.Parameters.AddWithValue("@email", email);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_company comp = new e_company();
                        comp.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        comp.companyName = reader.GetValue(1).ToString();
                        comp.address = reader.GetValue(2).ToString();
                        comp.email = reader.GetValue(3).ToString();
                        comp.gstno = Convert.ToInt32(reader.GetValue(4).ToString());
                        comp.contactno = reader.GetValue(5).ToString();
                        comp.isActive = Convert.ToBoolean(reader.GetValue(6).ToString() == "1" ? true : false);
                        lstComp.Add(comp);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstComp;
        }
    }

}
