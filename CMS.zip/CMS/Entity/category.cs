﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class e_category
    {
        public int id { get; set; }
        public string categoryname { get; set; }
        public string categorycode { get; set; }
        public bool isActive { get; set; }
    }
}
