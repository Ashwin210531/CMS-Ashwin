﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class e_company
    {
        public int id { get; set; }
        public string companyName { get; set; }
        public string address { get; set; }
        public string email { get; set; }
        public long gstno { get; set; }
        public string contactno { get; set; }
        public bool isActive { get; set; }

    }
}
