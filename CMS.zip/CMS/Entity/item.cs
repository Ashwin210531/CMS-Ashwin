﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity 
{
    public class e_item
    {
        public int id { get; set; }
        public int categoryid { get; set; }
        public int subcategoryid { get; set; }
        public string productname { get; set; }
        public string productcode { get; set; }
        public bool isactive { get; set; }
    }
}
